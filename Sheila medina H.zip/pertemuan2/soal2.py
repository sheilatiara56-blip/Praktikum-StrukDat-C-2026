barang = ("B001", "Laptop Gaming", 15000000)
print(barang[-1])

# barang.append("orange")
# thistuple = tuple(y)
# print(thistuple)  
'''penambahan value orange ga berhasil karena tuple itu unchangeable 
jadi harus diubah ke list dulu baru diubah lagi ke tuple'''


(kode, nama, harga) = barang

print(kode)
print(nama)
print(harga)